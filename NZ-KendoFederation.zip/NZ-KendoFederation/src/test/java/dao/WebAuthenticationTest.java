///*
// * To change this license header, choose License Headers in Project Properties.
// * To change this template file, choose Tools | Templates
// * and open the template in the editor.
// */
//package dao;
//
//import java.util.Set;
//import org.junit.jupiter.api.Test;
//
///**
// *
// * @author lachl
// */
//public class WebAuthenticationTest {
//
//    private WebAuthenticationJdbcDAO webJdbc = new WebAuthenticationJdbcDAO();
//    
//    @Test
//    public void checkAuthen(){
//        Set<String> roles = webJdbc.checkPath("GET", "http://sfeaweda");
//        System.out.println(roles.toString());
//    }
//}
